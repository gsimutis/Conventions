A = load('Lifetime16_5_4_2_0.1_2000000.dat');
nu_bins = 20;
binwidth = 10000/ nu_bins;
Centers = binwidth/2 : binwidth : 10000;
[Y1,X] = hist(A, Centers);
bar(X,Y1,0.8,'FaceColor',[0.2,0.2,0.5], 'EdgeColor','none');

hold on;

B = load('Lifetime16_5_4_2_0.2_2000000.dat');
nu_bins = 20;
binwidth = 10000/ nu_bins;
Centers = binwidth/2 : binwidth : 10000;
[Y2,X2] = hist(B, Centers);
bar(X,Y2,0.4,'FaceColor',[0,0.7,0.7],'EdgeColor',[0,0.7,0.7]);
hold off

legend('history = 2','history = 3') % add legend
text1 = {'Using 16 players, probability = 0.1, 2 samples'};
text2 = {'simulated 2000000 periods'};
text(800,3000,text1, 'FontSize', 14);
text(800,2500,text2, 'FontSize', 14)


set(gca, 'FontSize', 16);
xlabel('Lifetime (periods)','FontSize', 16);
ylabel('Number of occurances', 'FontSize', 16);
box on;
grid on;
