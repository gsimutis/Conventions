% a 2-D version with random pick of the 'friends'
% 16 players with t memory, eps probability of mistake
% We use strings 'L' and 'R'
%
% The game proceeds by a player first picking a number of friends at random
% Then randomly picking some number of 'stories' (samples) from each friend and then
% making a decision.
%
% The player considers his own information and that of his friends equally
% good, therefore, we allow the player to also choose himself for
% information

% In this simulation we alter the number of samples that are probed of the agents 
%
% We output arrays of Lifetime for each configuration. Also, we output the
% number of changes of conventions that happened for each configuration.

clear all;
close all;

players = 16; %number of players
t = 10; % number of encounters kept in memory
friends = 4; % number of friends to consult before making a decision
%samples = 1; % number of encounters probed to make a decision
eps = 0.1; % probability of mistake
periods = 5000000; % number of periods to be played

allchanges = [];

for i = 1:10
    samples = i;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initial conditions 0 = L, 1 = R
start = 'L';
W = {}; % the world
for i = 1:players
    W{i}(1:t)=start;
end

%display intial setup
W;

%For data analysis
Lifetime = []; % put lifetime number in periods 
%Variables to check that everything works
LifetimeL = []; % for the histogram of L-convention lifetimes
LifetimeR = [];


curLifetime = 0;
curLifetimeL = 0;
curLifetimeR = 0;

% start the game
for i = 1: periods
    % i
    %Check what is the current convention
    
    if i == 1    % For the first period read in the convention         
        for p = 1:players
        curW(p) = W{p}(t);
        end
        numL = countmember('L',curW);
        numR = countmember('R',curW);
        if numL > numR
            curConv = 'L';
        elseif numR > numL
            curConv = 'R';
        else    % If the initial state is equal, then pick one at random
            ini_conv = randi(2,1);
            if ini_conv == 1
                curConv = 'L';
            else
                curConv = 'R';
            end
        end
        
    else curConv = newConv; % For other periods, use previous convention
    
    end
    
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%% Decision making          %%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    %Which player makes a decision
    p = randi(players,1);
    
    %step 1: find the best choice
    
    %choose which friends to ask
    f = randi(players,friends,1);
    
    %keep count and see which choice is statistically better
    sumL = 0;
    sumR = 0;
    
    for ff = 1:friends
        
    
    %choose which encounters to probe
    a = randi(t,samples,1);
    
      for j = 1:samples
        % Check the first player
        if strcmpi(W{ff}(a(j)),'L')
            sumL = sumL +1;
        elseif strcmpi(W{ff}(a(j)),'R')
            sumR = sumR +1;
        end

      end
    end
    % see which choice is preffered
    if sumL > sumR
        BC = 'L';
        WC = 'R';
    elseif sumR > sumL
        BC = 'R';
        WC = 'L';
    else
        % If the number of the historical decisions is the same for R and
        % L, the player tosses a coin and chooses at random
        coin = rand;
        if coin <0.5
            BC = 'L';
            WC = 'R';
        else
            BC = 'R';
            WC = 'L';
        end
    end
    
    %step 2: see what choices the players make
    a = rand;
    if a > eps
        Choice = BC;
    else
        Choice = WC;
    end
    
    %step 3: update the hhstory
    for jj = 1:t-1
        W{p}(jj) = W{p}(jj+1);
    end
    W{p}(t) = Choice;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%% Collect data for analysis%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %Check what is the current convention
    for p = 1:players
    newW(p) = W{p}(t);
    end
    numL = countmember('L',newW);
    numR = countmember('R',newW);
    if numL > numR
        newConv = 'L';
    elseif numR > numL
        newConv = 'R';
    else
        % if it is half-split, consider it to stay the same
        newConv = curConv;
    end
    
    if strcmpi(newConv,curConv) % If the convention stays the same 
        curLifetime = curLifetime + 1;
        if strcmpi(newConv,'L')
            curLifetimeL = curLifetimeL + 1;
        else
            curLifetimeR = curLifetimeR + 1;
        end
            if i == periods  % IF end of the game
            % add the lifetime of this last convention to a histo
            Lifetime = [Lifetime; curLifetime];
                if strcmpi(curConv,'L')
                  LifetimeL = [LifetimeL; curLifetime];
                else
                  LifetimeR = [LifetimeR; curLifetime];
                end
            end

      
            
    else                            % If the convention changes
        % step 1 - add the lifetime of this last convention to a histo
        
        Lifetime = [Lifetime; curLifetime]; 
        if strcmpi(curConv,'L')
            LifetimeL = [LifetimeL; curLifetime];
        else
            LifetimeR = [LifetimeR; curLifetime];
        end

        % step 2 - reset the lifetime
        curLifetime = 1;
        if strcmpi(newConv,'L')
            curLifetimeL = 1;
            curLifetimeR = 0;
        else
            curLifetimeR = 1;
            curLifetimeL = 0;
        end
    end
    clear curW;
end
changes = length(Lifetime);
changesvar = [i changes];
allchanges = [allchanges; changesvar];

nu_bins = 200;
binwidth = periods/20 / nu_bins;
Centers = binwidth/2 : binwidth : periods/20;
[A,X] = hist(Lifetime, Centers);

bar(X,A);
%See what is the current state
W;

%Save the Data:
% Lifetime
outputfilename = ['Lifetime',num2str(players),'_',num2str(t),'_',num2str(friends),'_',num2str(samples),'_',num2str(eps),'_',num2str(periods),'.dat'];
dlmwrite(outputfilename,Lifetime);
% Histogram prelim
Histogram = [X' A'];
outputfilename = ['Histogram',num2str(players),'_',num2str(t),'_',num2str(friends),'_',num2str(samples),'_',num2str(eps),'_',num2str(periods),'.dat'];
dlmwrite(outputfilename,Histogram);


figfilename = ['fig',num2str(players),'_',num2str(t),'_',num2str(friends),'_',num2str(samples),'_',num2str(eps),'_',num2str(periods),'.fig'];
jpgfilename = ['jpg',num2str(players),'_',num2str(t),'_',num2str(friends),'_',num2str(samples),'_',num2str(eps),'_',num2str(periods),'.jpg'];

print( '-djpeg', jpgfilename)

end

changesfilename = 'changes.dat';
dlmwrite(changesfilename,allchanges);

