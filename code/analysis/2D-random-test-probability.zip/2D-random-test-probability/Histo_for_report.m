A = load('Lifetime16_2_4_2_0.1_2000000.dat');
nu_bins = 20;
binwidth = 3000/ nu_bins;
Centers = binwidth/2 : binwidth : 3000;
[Y1,X] = hist(A, Centers);
bar(X,Y1);

set(gca, 'FontSize', 16);
xlabel('Lifetime (periods)','FontSize', 16);
ylabel('Number of occurances', 'FontSize', 16);
box on;
grid on;